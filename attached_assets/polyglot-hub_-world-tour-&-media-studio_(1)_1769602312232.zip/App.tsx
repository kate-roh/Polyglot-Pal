
import React, { useState } from 'react';
import { AppMode, Destination, Character, Message, JourneyReport } from './types';
import { usePolyglotEngine } from './hooks/usePolyglotEngine';
import Sidebar from './components/Sidebar';
import UnifiedDashboard from './components/UnifiedDashboard';
import WorldMap from './components/WorldMap';
import ChatInterface from './components/ChatInterface';
import MediaStudio from './components/MediaStudio';
import Vault from './components/Vault';
import JourneyLog from './components/JourneyLog';
import LevelTest from './components/LevelTest';
import GrammarLab from './components/GrammarLab';
import LevelInfoModal from './components/LevelInfoModal';
import LiveTutor from './components/LiveTutor';
import ImageExplorer from './components/ImageExplorer';

const App: React.FC = () => {
  const [mode, setMode] = useState<AppMode>('HOME');
  const [showLevelInfo, setShowLevelInfo] = useState(false);
  const [selectedDest, setSelectedDest] = useState<Destination | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [character, setCharacter] = useState<Character | null>(null);
  const [loading, setLoading] = useState(false);

  const { gemini, data, actions } = usePolyglotEngine();
  const { stats, bookmarks, mediaHistory, journeyHistory } = data;

  const handleStartJourney = async (dest: Destination) => {
    setLoading(true);
    setSelectedDest(dest);
    try {
      const char = await gemini.generateCharacter(dest, 'Tourist meeting a local');
      setCharacter(char);
      setMessages([{ role: 'model', content: `Welcome to ${dest.city}! I'm ${char.name}. How can I help you today?`, timestamp: Date.now() }]);
      setMode('WORLD_TOUR');
    } catch (e) {
      alert("AI NPC 생성 실패");
    } finally {
      setLoading(false);
    }
  };

  const handleSendMessage = async (text: string) => {
    if (!selectedDest || !character) return;
    const userMsg: Message = { role: 'user', content: text, timestamp: Date.now() };
    setMessages(prev => [...prev, userMsg]);
    
    try {
      const weatherData = { temp: 22, condition: 'Sunny', tip: 'Take a walk!' };
      const response = await gemini.chat(selectedDest, character, messages, text, 10, weatherData);
      setMessages(prev => [...prev, { role: 'model', content: response.content, timestamp: Date.now() }]);
      actions.addXP(10);
    } catch (e) { console.error(e); }
  };

  const renderView = () => {
    switch (mode) {
      case 'HOME': return <UnifiedDashboard stats={stats} recentHistory={mediaHistory} bookmarks={bookmarks} onStartMission={() => setMode('MEDIA_STUDIO')} onReviewNow={() => setMode('VAULT')} onStartLevelTest={() => setMode('LEVEL_TEST')} onDeleteHistory={id => actions.deleteHistoryItem(id, 'media')} onLevelClick={() => setShowLevelInfo(true)} />;
      case 'WORLD_TOUR': 
        if (selectedDest && character) {
          return (
            <ChatInterface 
              destination={selectedDest} character={character} weather={{temp: 22, condition: 'Sunny', localDesc: '', tip: 'It is a beautiful day to explore the city!'}} 
              messages={messages} politeness={10} onSendMessage={handleSendMessage} onEndJourney={() => {setSelectedDest(null); setCharacter(null); setMessages([]); setMode('HOME');}}
              scenarios={[{id:'1', name:'Street Vendor', icon:'fa-shop', image:'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad'}]} currentScenario={{id: '1', name: 'City Center', icon: 'fa-city', image: selectedDest.image}} onSelectScenario={() => {}} 
            />
          );
        }
        return <WorldMap onSelect={handleStartJourney} history={journeyHistory} />;
      case 'EXPLORER': return <ImageExplorer targetLanguage={{code: 'en', name: 'English', flag: '🇺🇸'}} />;
      case 'TUTOR': return <div className="p-4 md:p-8 h-full"><LiveTutor targetLanguage={{code: 'en', name: 'English', flag: '🇺🇸'}} /></div>;
      case 'LEVEL_TEST': return <LevelTest gemini={gemini} onComplete={() => setMode('HOME')} onCancel={() => setMode('HOME')} />;
      case 'GRAMMAR_LAB': return <GrammarLab gemini={gemini} userStats={stats} onAddXP={actions.addXP} />;
      case 'MEDIA_STUDIO': return <MediaStudio gemini={gemini} onAddXP={actions.addXP} onToggleBookmark={actions.toggleBookmark} history={mediaHistory} onSaveResult={actions.saveMediaResult} onDeleteHistory={id => actions.deleteHistoryItem(id, 'media')} />;
      case 'VAULT': return <Vault bookmarks={bookmarks} onToggleBookmark={actions.toggleBookmark} onAddXP={actions.addXP} onStartTraining={() => {}} />;
      case 'HISTORY': return <JourneyLog history={journeyHistory} mediaHistory={mediaHistory} savedExpressions={[]} onSaveExpression={() => {}} onDeleteLog={id => actions.deleteHistoryItem(id, 'media')} />;
      default: return <UnifiedDashboard stats={stats} recentHistory={mediaHistory} bookmarks={bookmarks} onStartMission={() => setMode('MEDIA_STUDIO')} onReviewNow={() => setMode('VAULT')} onStartLevelTest={() => setMode('LEVEL_TEST')} onDeleteHistory={() => {}} onLevelClick={() => setShowLevelInfo(true)} />;
    }
  };

  return (
    <div className="flex flex-col md:flex-row h-screen bg-[#0b0e14] text-slate-100 overflow-hidden">
      <div className="hidden md:block">
        <Sidebar mode={mode} setMode={(m) => { setMode(m); if(m!=='WORLD_TOUR') {setSelectedDest(null); setCharacter(null);} }} stats={stats} />
      </div>

      <main className="flex-1 overflow-hidden flex flex-col relative">
        <header className="h-14 md:h-16 border-b border-white/5 flex justify-between items-center bg-black/40 z-[60] backdrop-blur-xl px-4 pt-[env(safe-area-inset-top)]">
           <div className="flex items-center gap-3">
              <button className="md:hidden w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center shadow-lg shadow-indigo-600/20" onClick={() => setMode('HOME')}>
                 <i className="fas fa-bolt text-sm"></i>
              </button>
              <h2 className="text-[10px] md:text-sm font-black italic tracking-widest uppercase text-indigo-400 truncate max-w-[150px]">
                {mode.replace('_', ' ')}
              </h2>
           </div>
           
           <div className="flex items-center gap-2">
              <div onClick={() => setShowLevelInfo(true)} className="flex items-center gap-2 bg-indigo-500/10 px-3 py-1 rounded-full border border-indigo-500/20 cursor-pointer active:scale-95 transition-transform">
                <span className="text-[10px] font-black text-indigo-400">Lv.{stats.level}</span>
                <div className="hidden xs:block w-12 h-1 bg-white/5 rounded-full overflow-hidden">
                   <div className="h-full bg-indigo-500" style={{width: `${(stats.xp/500)*100}%`}}></div>
                </div>
              </div>
           </div>
        </header>

        <div className="flex-1 overflow-y-auto custom-scrollbar bg-[#0b0e14]">
          {loading ? (
            <div className="h-full flex flex-col items-center justify-center">
              <div className="w-12 h-12 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
              <p className="mt-4 text-[10px] font-black uppercase text-indigo-400 animate-pulse tracking-widest">Neural Linking...</p>
            </div>
          ) : renderView()}
        </div>

        <nav className="md:hidden fixed bottom-0 left-0 right-0 glass border-t border-white/10 px-6 py-4 pb-[calc(1.5rem+env(safe-area-inset-bottom))] flex justify-between items-center z-[100] shadow-[0_-10px_40px_rgba(0,0,0,0.8)]">
           {[
             { id: 'HOME', icon: 'fa-house' },
             { id: 'WORLD_TOUR', icon: 'fa-globe' },
             { id: 'EXPLORER', icon: 'fa-camera' },
             { id: 'MEDIA_STUDIO', icon: 'fa-clapperboard' },
             { id: 'HISTORY', icon: 'fa-clock-rotate-left' }
           ].map(item => (
             <button key={item.id} onClick={() => { setMode(item.id as AppMode); if(item.id!=='WORLD_TOUR') {setSelectedDest(null); setCharacter(null);} }} className={`relative p-2 transition-all ${mode === item.id ? 'text-indigo-400 scale-125' : 'text-slate-600'}`}>
               <i className={`fas ${item.icon} text-xl`}></i>
               {mode === item.id && <span className="absolute -top-1 right-0 w-1.5 h-1.5 bg-indigo-400 rounded-full"></span>}
             </button>
           ))}
        </nav>
      </main>

      {showLevelInfo && <LevelInfoModal userStats={stats} onClose={() => setShowLevelInfo(false)} />}
    </div>
  );
};

export default App;
