
import { GoogleGenAI, Type, Modality } from '@google/genai';
import { Character, Destination, Message, AnalysisResult, LevelTestQuestion, LevelTestResult, GrammarLesson } from '../types';

export class GeminiService {
  private aiInstance: GoogleGenAI | null = null;
  private audioCtx: AudioContext | null = null;

  private get ai() {
    if (!this.aiInstance) {
      const apiKey = process.env.API_KEY;
      if (!apiKey) throw new Error("API_KEY missing");
      this.aiInstance = new GoogleGenAI({ apiKey });
    }
    return this.aiInstance;
  }

  private safeParse(text: string, defaultValue: any = {}): any {
    try {
      if (!text) return defaultValue;
      const cleaned = text.replace(/```json/gi, '').replace(/```/g, '').trim();
      const startBrace = cleaned.indexOf('{');
      const startBracket = cleaned.indexOf('[');
      const endBrace = cleaned.lastIndexOf('}');
      const endBracket = cleaned.lastIndexOf(']');

      let jsonStr = cleaned;
      if (startBrace !== -1 && endBrace !== -1 && (startBracket === -1 || startBrace < startBracket)) {
        jsonStr = cleaned.substring(startBrace, endBrace + 1);
      } else if (startBracket !== -1 && endBracket !== -1) {
        jsonStr = cleaned.substring(startBracket, endBracket + 1);
      }
      
      const parsed = JSON.parse(jsonStr);
      if (Array.isArray(defaultValue) && !Array.isArray(parsed)) return defaultValue;
      return parsed;
    } catch (e) {
      console.warn("JSON Parse Failed:", text);
      return defaultValue;
    }
  }

  async unlockAudio() {
    try {
      if (!this.audioCtx) {
        this.audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      }
      if (this.audioCtx.state === 'suspended') await this.audioCtx.resume();
      return true;
    } catch (e) { return false; }
  }

  async analyzeMedia(input: { type: 'youtube' | 'file' | 'manual', content: string, mimeType?: string, title?: string }): Promise<AnalysisResult> {
    const isYoutube = input.type === 'youtube';
    
    const sysPrompt = `Linguistic analysis expert. Analyze content and return ONLY raw JSON.
    Structure:
    {
      "summary": "Korean summary",
      "cefrLevel": "A1-C2",
      "script": [{
        "speaker": "Name",
        "text": "Original",
        "translation": "Korean",
        "timestamp": "MM:SS",
        "seconds": number,
        "vocabulary": [{"word": "string", "meaning": "string"}],
        "idioms": [{"phrase": "string", "meaning": "string"}]
      }],
      "notes": [{"title": "Concept", "content": "Explanation"}]
    }`;

    try {
      const config: any = { 
        responseMimeType: 'application/json',
        temperature: 0.1 
      };

      if (isYoutube) {
        config.tools = [{ googleSearch: {} }];
      }

      let contents;
      if (input.type === 'file' && input.mimeType) {
        contents = {
          parts: [
            { inlineData: { data: input.content, mimeType: input.mimeType } },
            { text: sysPrompt }
          ]
        };
      } else if (isYoutube) {
        contents = `Find and analyze the actual content and transcript of this YouTube video: ${input.content}\n\nTask: ${sysPrompt}`;
      } else {
        contents = `${sysPrompt}\n\nAnalyze this: "${input.content}"`;
      }

      const response = await this.ai.models.generateContent({
        model: isYoutube ? 'gemini-3-pro-preview' : 'gemini-3-flash-preview',
        contents,
        config
      });

      const parsed = this.safeParse(response.text || '{}', {});
      
      return {
        id: Date.now().toString(),
        title: input.title || (isYoutube ? 'YouTube Session' : 'Analysis'),
        date: new Date().toISOString(),
        type: input.type,
        source: input.content,
        summary: parsed.summary || 'Summary unavailable.',
        cefrLevel: parsed.cefrLevel || 'Unknown',
        script: Array.isArray(parsed.script) ? parsed.script : [],
        vocabulary: [],
        idioms: [],
        notes: Array.isArray(parsed.notes) ? parsed.notes : [],
        keySentences: [],
        quiz: []
      };
    } catch (e) {
      console.error("Analysis Error:", e);
      throw new Error("분석 도중 오류가 발생했습니다. 네트워크 연결을 확인해 주세요.");
    }
  }

  async speak(text: string, langCode: string = 'en') {
    try {
      if (!this.audioCtx) await this.unlockAudio();
      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash-preview-tts',
        contents: [{ parts: [{ text }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } }
        }
      });
      const base64 = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64 && this.audioCtx) {
        const binary = atob(base64);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
        const dataInt16 = new Int16Array(bytes.buffer);
        const buffer = this.audioCtx.createBuffer(1, dataInt16.length, 24000);
        const channelData = buffer.getChannelData(0);
        for (let i = 0; i < dataInt16.length; i++) channelData[i] = dataInt16[i] / 32768.0;
        const source = this.audioCtx.createBufferSource();
        source.buffer = buffer;
        source.connect(this.audioCtx.destination);
        source.start();
      }
    } catch (e) {}
  }

  async chat(destination: Destination, character: Character, history: Message[], input: string, politeness: number, weather?: any): Promise<{ content: string }> {
    const weatherInfo = weather ? `Env: ${weather.condition}, ${weather.temp}°C. Tip: ${weather.tip}` : "";
    const response = await this.ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [
        ...history.slice(-8).map(m => ({ role: m.role, parts: [{ text: m.content }] })),
        { role: 'user', parts: [{ text: input }] }
      ],
      config: {
        systemInstruction: `You are ${character.name} in ${destination.city}. Personality: ${character.personality}. Kindness: ${character.kindness}/10. ${weatherInfo}. User Politeness: ${politeness}/10. Speak ONLY in ${destination.language.name}. Be realistic and concise.`,
      }
    });
    return { content: response.text || "" };
  }

  async generateGrammarLesson(langName: string, level: number, topic?: string): Promise<GrammarLesson> {
    const response = await this.ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `Grammar for ${langName} Lv.${level}. Topic: ${topic || 'Daily grammar'}.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            topic: { type: Type.STRING },
            explanation: { type: Type.STRING },
            examples: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { original: { type: Type.STRING }, translation: { type: Type.STRING } }, required: ["original", "translation"] } },
            exercises: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { question: { type: Type.STRING }, options: { type: Type.ARRAY, items: { type: Type.STRING } }, answer: { type: Type.STRING }, explanation: { type: Type.STRING } }, required: ["question", "options", "answer", "explanation"] } }
          },
          required: ["topic", "explanation", "examples", "exercises"]
        }
      }
    });
    return this.safeParse(response.text || '{}', { topic: "", explanation: "", examples: [], exercises: [] });
  }

  async generateLevelTest(langName: string): Promise<LevelTestQuestion[]> {
    const response = await this.ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `Generate diagnostic test for ${langName}.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: { id: { type: Type.INTEGER }, type: { type: Type.STRING }, question: { type: Type.STRING }, options: { type: Type.ARRAY, items: { type: Type.STRING } }, correctAnswer: { type: Type.STRING }, audioText: { type: Type.STRING } },
            required: ["id", "type", "question"]
          }
        }
      }
    });
    return this.safeParse(response.text || '[]', []);
  }

  async analyzeLevelTest(langName: string, answers: any[]): Promise<LevelTestResult> {
    const response = await this.ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `Analyze test: ${JSON.stringify(answers)}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: { score: { type: Type.NUMBER }, proficiency: { type: Type.STRING }, strengths: { type: Type.ARRAY, items: { type: Type.STRING } }, weaknesses: { type: Type.ARRAY, items: { type: Type.STRING } }, summary: { type: Type.STRING }, recommendedLevel: { type: Type.NUMBER } },
          required: ["score", "proficiency", "summary", "recommendedLevel"]
        }
      }
    });
    return this.safeParse(response.text || '{}', { score: 0, proficiency: 'A1', strengths: [], weaknesses: [], summary: "", recommendedLevel: 1 });
  }

  async generateCharacter(destination: Destination, scenario: string): Promise<Character> {
    const response = await this.ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `NPC for ${destination.city}. Scenario: ${scenario}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: { name: { type: Type.STRING }, gender: { type: Type.STRING }, personality: { type: Type.STRING }, kindness: { type: Type.NUMBER }, mood: { type: Type.STRING } },
          required: ["name", "gender", "personality", "kindness", "mood"]
        }
      }
    });
    return this.safeParse(response.text || '{}', { name: "Local", gender: "Female", personality: "Friendly", kindness: 10, mood: "Happy" });
  }

  async evaluateShadowing(original: string, recording: string): Promise<{ score: number; feedback: string }> {
    const response = await this.ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Grade shadowing. Target: "${original}", Audio: "${recording}".`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: { score: { type: Type.NUMBER }, feedback: { type: Type.STRING } },
          required: ["score", "feedback"]
        }
      }
    });
    return this.safeParse(response.text || '{}', { score: 0, feedback: "" });
  }
}
