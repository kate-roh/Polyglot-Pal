
import { useState, useEffect, useRef } from 'react';
import { UserStats, Bookmark, AnalysisResult, JourneyReport, Language } from '../types';
import { GeminiService } from '../services/geminiService';

export const usePolyglotEngine = () => {
  const gemini = useRef(new GeminiService()).current;

  // Initial State Helpers
  const createInitialStats = (): UserStats => {
    const todayStr = new Date().toISOString().split('T')[0];
    return {
      level: 1, xp: 0, xpToday: 0, streak: 0,
      totalJourneys: 0, totalShadowings: 0, totalWords: 0,
      proficiency: 'Unranked',
      lastActivityDate: Date.now(),
      lastLoginDate: todayStr,
      dailyHistory: [{ date: todayStr, xp: 0 }]
    };
  };

  const getRankFromLevel = (level: number): string => {
    if (level <= 5) return 'A1 (Beginner)';
    if (level <= 15) return 'A2 (Elementary)';
    if (level <= 30) return 'B1 (Intermediate)';
    if (level <= 50) return 'B2 (Upper Intermediate)';
    if (level <= 80) return 'C1 (Advanced)';
    return 'C2 (Mastery)';
  };

  // State Management
  const [stats, setStats] = useState<UserStats>(() => {
    const saved = localStorage.getItem('polyglot_stats');
    if (!saved) return createInitialStats();
    try {
      return JSON.parse(saved);
    } catch (e) {
      return createInitialStats();
    }
  });

  const [bookmarks, setBookmarks] = useState<Bookmark[]>(() => {
    const saved = localStorage.getItem('polyglot_bookmarks');
    return saved ? JSON.parse(saved) : [];
  });

  const [mediaHistory, setMediaHistory] = useState<AnalysisResult[]>(() => {
    const saved = localStorage.getItem('polyglot_media_history');
    return saved ? JSON.parse(saved) : [];
  });

  const [journeyHistory, setJourneyHistory] = useState<JourneyReport[]>(() => {
    const saved = localStorage.getItem('polyglot_journey_history');
    return saved ? JSON.parse(saved) : [];
  });

  // Persistence
  useEffect(() => {
    localStorage.setItem('polyglot_stats', JSON.stringify(stats));
    localStorage.setItem('polyglot_bookmarks', JSON.stringify(bookmarks));
    localStorage.setItem('polyglot_media_history', JSON.stringify(mediaHistory));
    localStorage.setItem('polyglot_journey_history', JSON.stringify(journeyHistory));
  }, [stats, bookmarks, mediaHistory, journeyHistory]);

  // Actions
  const addXP = (amount: number, score?: number) => {
    const todayStr = new Date().toISOString().split('T')[0];
    setStats(prev => {
      const finalAmount = Math.round(amount * (score && score >= 90 ? 1.5 : 1));
      let newTotalXP = prev.xp + finalAmount;
      let newLevel = prev.level;
      while (newTotalXP >= 500) {
        newLevel += 1;
        newTotalXP -= 500;
      }
      
      const history = [...(prev.dailyHistory || [])];
      const todayIdx = history.findIndex(h => h.date === todayStr);
      if (todayIdx > -1) {
        history[todayIdx] = { ...history[todayIdx], xp: history[todayIdx].xp + finalAmount };
      } else {
        history.push({ date: todayStr, xp: finalAmount });
      }

      return {
        ...prev,
        xp: newTotalXP,
        xpToday: (prev.lastLoginDate === todayStr ? prev.xpToday : 0) + finalAmount,
        level: newLevel,
        proficiency: getRankFromLevel(newLevel),
        dailyHistory: history,
        lastLoginDate: todayStr
      };
    });
  };

  const toggleBookmark = (item: any, type: Bookmark['type'], sourceType: Bookmark['sourceType']) => {
    setBookmarks(prev => {
      const exists = prev.find(b => b.text === (item.text || item.word || item.phrase));
      if (exists) return prev.filter(b => b.id !== exists.id);
      return [{
        id: Math.random().toString(36).substr(2, 9),
        text: item.text || item.word || item.phrase,
        translation: item.translation || item.meaning,
        type, 
        sourceType, 
        timestamp: Date.now()
      }, ...prev];
    });
  };

  const saveMediaResult = (res: AnalysisResult) => {
    setMediaHistory(prev => [res, ...prev]);
  };

  const deleteHistoryItem = (id: string, group: 'media' | 'journey') => {
    if (group === 'media') {
      setMediaHistory(prev => prev.filter(i => i.id !== id));
    } else {
      setJourneyHistory(prev => prev.filter(i => i.id !== id));
    }
  };

  return {
    gemini,
    data: { stats, bookmarks, mediaHistory, journeyHistory },
    actions: { addXP, toggleBookmark, saveMediaResult, deleteHistoryItem, setJourneyHistory }
  };
};
